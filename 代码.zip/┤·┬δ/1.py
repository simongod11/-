import torch
# import cv2
# import numpy as np

# #读取灰度图片
# img = cv2.imread('img2.jpg', 0)
# cv2.imshow('img',img)
# cv2.waitKey(0)

# #对图片进行Canny边缘检测
# edge_img = cv2.Canny(img, 50, 100)


# #将边缘检测图片储存，命名为'edges_img.jpg'
# cv2.imwrite('edges_img.jpg', edge_img)


# #读取边缘图片
# edge_img = cv2.imread('edges_img.jpg', 0)


# #下面规划ROI区域
# mask = np.zeros_like(edge_img)
# mask = cv2.fillPoly(mask,np.array([[[0, 372], [303, 213], [338, 213], [644, 372]]]),color=255)
# masked_edge_img = cv2.bitwise_and(edge_img, mask)


# #将ROI边缘图片储存，命名为'masked_edge_img.jpg'
# cv2.imwrite('masked_edge_img.jpg', masked_edge_img)


# def calculate_slope(line):
# #此函数用于计算直线斜率
#     x_1, y_1, x_2, y_2 = line[0]
#     return (y_2 - y_1) / (x_2 - x_1)
# #读取边缘图片'masked_edge_img.jpg'
# edge_img = cv2.imread('masked_edge_img.jpg', 0)
# #可以取到所有线段
# lines = cv2.HoughLinesP(edge_img, 1, np.pi / 180, 15, minLineLength=50,maxLineGap=15)
# # 按照斜率分左右车道线，左侧车道线斜率大于零/，右侧车道线斜率小于零\
# left_lines = [line for line in lines if calculate_slope(line) > 0]
# right_lines = [line for line in lines if calculate_slope(line) < 0]
# def reject_abnormal_lines(lines, threshold):
# #此步可以将误导线段去除
#     slopes = [calculate_slope(line) for line in lines]
#     while len(lines) > 0:
#         mean = np.mean(slopes)
#         diff = [abs(s - mean) for s in slopes]
#         idx = np.argmax(diff)
#         if diff[idx] > threshold:
#             slopes.pop(idx)
#             lines.pop(idx)
#         else:
#             break
#     return lines
# left_lines = reject_abnormal_lines(left_lines, threshold=0.3)
# right_lines = reject_abnormal_lines(right_lines, threshold=0.3)
# def least_squares_fit(lines):
# #拟合直线
#     # 取出线上所有坐标点
#     x_coords = np.ravel([[line[0][0], line[0][2]] for line in lines])
#     y_coords = np.ravel([[line[0][1], line[0][3]] for line in lines])


#     #拟合直线
#     poly = np.polyfit(x_coords, y_coords, deg=1)


#     #两点确定直线
#     point_min = (np.min(x_coords), np.polyval(poly, np.min(x_coords)))
#     point_max = (np.max(x_coords), np.polyval(poly, np.max(x_coords)))
#     return np.array([point_min, point_max], dtype=np.int)

# left_line = least_squares_fit(left_lines)
# right_line = least_squares_fit(right_lines)


# #将蒙版覆盖，得到最终结果
# img = cv2.imread('img2.jpg', 1)
# cv2.line(img, tuple(left_line[0]), tuple(left_line[1]), color=(0, 255, 255), thickness=2)
# cv2.line(img, tuple(right_line[0]), tuple(right_line[1]), color=(0, 255, 255), thickness=2)


# #展示图片
# cv2.imshow('line', img)
# cv2.waitKey(0)