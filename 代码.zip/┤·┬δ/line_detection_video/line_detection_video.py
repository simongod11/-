import cv2
import logging
import numpy as np

#对于视频的处理我的方法是将视频的每一帧提取出来单独处理，最后再形成一个整体的视频
# 基本信息设置
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s: %(message)s')

#这个函数的作用是将每个帧的图片存储到名为‘video_pic’的文件夹下，方便进行分别操作
def save_image(num, image):

    image_path = 'video_pic/{}.jpg'.format(str(num))#图片存储路径

    cv2.imwrite(image_path, image)

#找到需要处理的视频
file_path = 'video.mp4'

vc = cv2.VideoCapture(file_path)

# 检测视频能否正常打开
if vc.isOpened():
    ret, frame = vc.read()
else:
    ret = False

#计数器，给每张图片命名
count = 0
frame_interval = 30
frame_interval_count = 0

# 开始进行图片分割和存储
while ret:
    #ret 是布尔值，如果能正确读取这一帧，则返回 True；如果文件读取到结尾，它的返回值就为 False。
    # frame 就是每一帧的图像，是一个三维矩阵。
    ret, frame = vc.read()
    if frame_interval_count % frame_interval == 0:
        save_image(count, frame)
        logging.info("num：" + str(count) + ", frame: " +
                     str(frame_interval_count))
        count += 1
    frame_interval_count += 1
    cv2.waitKey(1)


#结束程序
vc.release()


#下面就是正常的每一张图片的处理过程了
#读取灰度图片
for i in range(0,8):
    img = cv2.imread('./video_pic/{}.jpg'.format(i), 0)


    #对图片进行Canny边缘检测
    edge_img = cv2.Canny(img, 50, 100)


    #将边缘检测图片储存，命名为'edges_img.jpg'
    cv2.imwrite('edges_img.jpg', edge_img)


    #读取边缘图片
    edge_img = cv2.imread('edges_img.jpg', 0)


    #下面规划ROI区域
    mask = np.zeros_like(edge_img)
    mask = cv2.fillPoly(mask,np.array([[[0, 372], [303, 213], [338, 213], [644, 372]]]),color=255)
    masked_edge_img = cv2.bitwise_and(edge_img, mask)


    #将ROI边缘图片储存，命名为'masked_edge_img.jpg'
    cv2.imwrite('masked_edge_img.jpg', masked_edge_img)


    def calculate_slope(line):
    #此函数用于计算直线斜率
        x_1, y_1, x_2, y_2 = line[0]
        return (y_2 - y_1) / (x_2 - x_1)


    #读取边缘图片'masked_edge_img.jpg'
    edge_img = cv2.imread('masked_edge_img.jpg', 0)


    #可以取到所有线段
    lines = cv2.HoughLinesP(edge_img, 1, np.pi / 180, 15, minLineLength=50,maxLineGap=15)


    # 按照斜率分左右车道线，左侧车道线斜率大于零/，右侧车道线斜率小于零\
    left_lines = [line for line in lines if calculate_slope(line) > 0]
    right_lines = [line for line in lines if calculate_slope(line) < 0]


    def reject_abnormal_lines(lines, threshold):
    #此步可以将误导线段去除
        slopes = [calculate_slope(line) for line in lines]
        while len(lines) > 0:
            mean = np.mean(slopes)
            diff = [abs(s - mean) for s in slopes]
            idx = np.argmax(diff)
            if diff[idx] > threshold:
                slopes.pop(idx)
                lines.pop(idx)
            else:
                break
        return lines


    left_lines = reject_abnormal_lines(left_lines, threshold=0.1)
    right_lines = reject_abnormal_lines(right_lines, threshold=0.1)


    def least_squares_fit(lines):
    #拟合直线
        # 取出线上所有坐标点
        x_coords = np.ravel([[line[0][0], line[0][2]] for line in lines])
        y_coords = np.ravel([[line[0][1], line[0][3]] for line in lines])


        #拟合直线
        poly = np.polyfit(x_coords, y_coords, deg=1)


        #两点确定直线
        point_min = (np.min(x_coords), np.polyval(poly, np.min(x_coords)))
        point_max = (np.max(x_coords), np.polyval(poly, np.max(x_coords)))
        return np.array([point_min, point_max], dtype=np.int)

    left_line = least_squares_fit(left_lines)
    right_line = least_squares_fit(right_lines)


    #将蒙版覆盖，得到最终结果
    img = cv2.imread('./video_pic/{}.jpg'.format(i), 1)
    cv2.line(img, tuple(left_line[0]), tuple(left_line[1]), color=(0, 255, 255), thickness=2)
    cv2.line(img, tuple(right_line[0]), tuple(right_line[1]), color=(0, 255, 255), thickness=2)

    #存储图片
    cv2.imwrite('./video_pic_part/img{}.jpg'.format(i),img)


#下面将处理好的视频图片合成一个视频
image=cv2.imread('./video_pic_part/img0.jpg')
image_info=image.shape
height=image_info[0]
width=image_info[1]
size=(height,width)


#视频不长，所以帧数设置的低一些
fps=3
fourcc=cv2.VideoWriter_fourcc(*"mp4v")
video = cv2.VideoWriter('after_video_whole.mp4', cv2.VideoWriter_fourcc(*"mp4v"), fps, (width,height)) #创建视频流对象-格式一

for i in range(0,8):
    image=cv2.imread('./video_pic_part/img{}.jpg'.format(i))
    video.write(image)  # 向视频文件写入一帧--只有图像，没有声音
cv2.waitKey()